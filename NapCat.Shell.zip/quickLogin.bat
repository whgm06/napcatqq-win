@echo off
REM 快速登录示例脚本
REM -q 参数是可选的，不传则使用二维码登录
REM 
REM 使用方法（删掉对应系统那行的 REM）：
REM ./launcher-user.bat 12345
REM ./launcher-win10-user.bat 12345
REM 如果是win11 修改下面这行的QQ号（12345）为自己的就行
./launcher.bat 12345
pause